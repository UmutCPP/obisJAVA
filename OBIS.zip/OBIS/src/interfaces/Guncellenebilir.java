package interfaces;

// Nesneye ait basit güncelleme işlemlerini tanımlar.
public interface Guncellenebilir {
    void emailGuncelle(String yeniEmail);
}
