package interfaces;

// Nesnenin konsola yazılabilir bir özetini döndürür.
public interface Goruntulenebilir {
    String goruntule();
}
