package model;

// Sistemdeki kullanıcı rollerini belirtir.
public enum Rol {
    ADMIN,
    OGRETMEN,
    OGRENCI
}
